module onlinetest {
	requires java.desktop;
}